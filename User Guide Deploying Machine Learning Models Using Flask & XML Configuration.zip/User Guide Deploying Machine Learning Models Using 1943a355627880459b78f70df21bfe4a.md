# User Guide: Deploying Machine Learning Models Using Flask & XML Configuration

## **Introduction**

This guide provides a step-by-step approach to deploying a **Machine Learning (ML) model** using **Flask**, with **XML-based configuration** for model parameters.

Flask serves as the **API backend**, while XML files store **model settings**, enabling flexibility in model management without modifying the codebase.

---

## **1. Prerequisites**

Before deployment, ensure the following:

🔹 Python **(>=3.8)** installed

🔹 Required libraries: `Flask`, `joblib`, `sklearn`, `lxml`

🔹 Trained **ML model (e.g., Decision Tree, Logistic Regression, or Neural Network)**

🔹 XML file containing model parameters

---

## **2. Setting Up the Flask Environment**

### **Step 1: Install Dependencies**

```
sh
CopyEdit
pip install flask joblib scikit-learn lxml

```

### **Step 2: Define the Project Structure**

```
csharp
CopyEdit
ml-flask-deployment/
│── model.pkl                  # Pre-trained ML model
│── config.xml                  # XML configuration file
│── app.py                      # Flask API
│── requirements.txt             # Dependencies
│── static/                      # Optional frontend files
│── templates/                   # Optional HTML templates

```

---

## **3. XML-Based Configuration File**

Store the model parameters in an XML file (`config.xml`):

```xml
xml
CopyEdit
<configuration>
    <model>
        <name>DecisionTreeClassifier</name>
        <version>1.0</version>
        <features>["age", "income", "credit_score"]</features>
        <threshold>0.5</threshold>
    </model>
    <server>
        <host>0.0.0.0</host>
        <port>5000</port>
        <debug>true</debug>
    </server>
</configuration>

```

---

## **4. Building the Flask API**

### **Step 1: Load the Model & Configuration**

```python
python
CopyEdit
from flask import Flask, request, jsonify
import joblib
import xml.etree.ElementTree as ET

# Load XML Configuration
def load_config():
    tree = ET.parse('config.xml')
    root = tree.getroot()
    config = {
        "model_name": root.find("./model/name").text,
        "threshold": float(root.find("./model/threshold").text),
        "host": root.find("./server/host").text,
        "port": int(root.find("./server/port").text),
        "debug": root.find("./server/debug").text.lower() == 'true'
    }
    return config

# Load Model
model = joblib.load("model.pkl")
config = load_config()

app = Flask(__name__)

```

---

### **Step 2: Define the Prediction API**

```python
python
CopyEdit
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    features = [data.get("age"), data.get("income"), data.get("credit_score")]

    prediction = model.predict([features])[0]

    return jsonify({
        "model": config["model_name"],
        "prediction": int(prediction),
        "threshold": config["threshold"]
    })

```

---

### **Step 3: Run the Flask App**

```python
python
CopyEdit
if __name__ == '__main__':
    app.run(host=config["host"], port=config["port"], debug=config["debug"])

```

Start the Flask server:

```
sh
CopyEdit
python app.py

```

The API will be available at:

```
arduino
CopyEdit
http://0.0.0.0:5000/predict

```

---

## **5. Testing the API**

### **Request Example (JSON)**

```json
json
CopyEdit
{
    "age": 35,
    "income": 60000,
    "credit_score": 720
}

```

### **Response Example (JSON)**

```json
json
CopyEdit
{
    "model": "DecisionTreeClassifier",
    "prediction": 1,
    "threshold": 0.5
}

```

---

## **6. Deploying on a Cloud Server**

### **Step 1: Install Gunicorn & Set Up WSGI**

```
sh
CopyEdit
pip install gunicorn

```

Create `wsgi.py`:

```python
python
CopyEdit
from app import app

if __name__ == "__main__":
    app.run()

```

### **Step 2: Run with Gunicorn**

```
sh
CopyEdit
gunicorn --bind 0.0.0.0:5000 wsgi:app

```

---

## **7. Conclusion**

This guide demonstrated **how to deploy an ML model using Flask**, leveraging **XML configuration** for dynamic settings. This approach ensures a flexible, scalable API for ML model deployment.