# Programming Microcontrollers for IoT Devices

## Introduction

Microcontrollers are at the core of Internet of Things (IoT) devices, enabling real-time data processing, connectivity, and automation. This guide provides an overview of microcontroller programming, key components, and a step-by-step approach to deploying microcontroller-based IoT applications.

## Understanding Microcontrollers in IoT

Microcontrollers are compact computing devices with a processor, memory, and input/output (I/O) peripherals. They are widely used in smart home automation, industrial monitoring, healthcare devices, and environmental sensors.

### Key Features of Microcontrollers for IoT:

- **Low Power Consumption:** Optimized for battery-powered applications.
- **Built-in Connectivity:** Support for Wi-Fi, Bluetooth, Zigbee, and LoRa.
- **Real-time Processing:** Handles sensor data and executes control logic.
- **Small Form Factor:** Suitable for embedded applications.

## Choosing the Right Microcontroller

Popular microcontrollers for IoT applications include:

| Microcontroller | Features | Use Case |
| --- | --- | --- |
| **ESP8266** | Wi-Fi enabled, low-cost | Smart home, automation |
| **ESP32** | Dual-core, Wi-Fi + Bluetooth | Industrial IoT, wearables |
| **Arduino Uno** | Easy-to-use, large community | Prototyping, education |
| **STM32** | High-performance, low-power | Industrial control, medical devices |
| **Raspberry Pi Pico** | Affordable, microPython support | Learning, DIY projects |

## Setting Up the Development Environment

To program a microcontroller, you need:

- **IDE & Compiler:** Arduino IDE, PlatformIO, or ESP-IDF for ESP-based chips.
- **Programming Language:** C, C++, or MicroPython.
- **Hardware Tools:** USB-to-serial adapter, breadboard, jumper wires, and sensors.

### Installation Steps

1. **Install Arduino IDE** (for ESP8266, ESP32, and Arduino Uno)
    - Download from [Arduino website](https://www.arduino.cc/)
    - Install necessary board libraries (ESP8266, ESP32, STM32, etc.)
2. **Set Up PlatformIO (VS Code Extension)**
    - Install [PlatformIO](https://platformio.org/)
    - Create a new project for your microcontroller
3. **Connect Microcontroller to Computer**
    - Use a USB cable or UART-to-USB adapter
    - Select the correct COM port in the IDE

## Writing Your First IoT Program

### Example: Blinking an LED (Arduino)

```cpp
void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);
  delay(1000);
  digitalWrite(LED_BUILTIN, LOW);
  delay(1000);
}

```

### Example: Sending Data to an IoT Cloud (ESP8266 + MQTT)

```cpp
#include <ESP8266WiFi.h>
#include <PubSubClient.h>

const char* ssid = "Your_WiFi";
const char* password = "Your_Password";
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    client.connect("ESP8266Client");
  }
  client.publish("iot/data", "Hello IoT World!");
  delay(2000);
}

```

## Debugging & Troubleshooting

- **Check Power Supply:** Ensure proper voltage levels.
- **Verify Serial Communication:** Use the `Serial Monitor` for debugging.
- **Update Firmware:** Install the latest board firmware and libraries.
- **Check Wi-Fi Credentials:** Incorrect SSID/password causes connection failure.

## Deploying IoT Applications

1. **Integrate Sensors:** Connect temperature, humidity, or motion sensors.
2. **Enable Cloud Connectivity:** Use MQTT, HTTP, or WebSockets.
3. **Optimize Power Consumption:** Use deep sleep mode for battery efficiency.
4. **Secure Data Transmission:** Implement TLS encryption and authentication.

## Conclusion

Programming microcontrollers for IoT devices requires a combination of hardware interfacing, embedded programming, and networking knowledge. By following this guide, developers can build smart, connected devices for various applications, from home automation to industrial monitoring.

## References

- Arduino Documentation: [https://www.arduino.cc/](https://www.arduino.cc/)
- ESP32 Development: [https://docs.espressif.com/](https://docs.espressif.com/)
- STM32 Guide: [https://www.st.com/en/microcontrollers-microprocessors/stm32.html](https://www.st.com/en/microcontrollers-microprocessors/stm32.html)