# Sentiment Analysis API Documentation

## Overview

The Sentiment Analysis API allows developers to analyze the sentiment of text data. The API processes textual input and returns a sentiment score, indicating whether the sentiment is positive, negative, or neutral.

## Base URL

```
https://api.sentimentanalysis.com/v1
```

## Authentication

The API requires authentication via an API key. Include the API key in the header of each request:

```
Authorization: Bearer YOUR_API_KEY
```

## Endpoints

### 1. Analyze Sentiment

**Endpoint:**

```
POST /analyze_sentiment
```

**Request Headers:**

```
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY
```

**Request Body:**

```
{
    "text": "I love this product! It's amazing."
}
```

**Response:**

```
{
    "sentiment": "positive",
    "confidence_score": 0.95
}
```

### 2. Batch Sentiment Analysis

**Endpoint:**

```
POST /batch_analyze_sentiment
```

**Request Body:**

```
{
    "texts": [
        "I love this product!",
        "This is terrible."
    ]
}
```

**Response:**

```
{
    "results": [
        { "text": "I love this product!", "sentiment": "positive", "confidence_score": 0.95 },
        { "text": "This is terrible.", "sentiment": "negative", "confidence_score": 0.89 }
    ]
}
```

## Error Handling

### Common Errors

| Error Code | Message | Cause |
| --- | --- | --- |
| 400 | Invalid request | Missing required parameters |
| 401 | Unauthorized | Invalid or missing API key |
| 500 | Internal server error | Issue with the server |

**Example Error Response:**

```
{
    "error": "Invalid request. Text parameter is missing."
}
```

## Rate Limits

- Free Plan: 100 requests per day
- Pro Plan: 10,000 requests per day