# API Documentation: RESTful Weather Service Using HTML & XML

## **1. Introduction**

In modern applications, accessing real-time weather data is essential for various industries, including travel, agriculture, and logistics. This document provides **comprehensive API documentation** for a RESTful weather service, demonstrating how to integrate weather data into applications.

The documentation follows industry best practices, using **HTML for structured formatting** and **XML for response formatting**.

---

## **2. Overview of the API**

### **Base URL**

All API requests should be made to the following base URL:

```
plaintext
CopyEdit
https://api.weatherdata.com/v1/

```

### **Authentication**

The API requires authentication via an API key.

- **Pass the API key as a query parameter** (`appid=YOUR_API_KEY`)
- **Or include it in the request header**:
    
    ```
    plaintext
    CopyEdit
    Authorization: Bearer YOUR_API_KEY
    
    ```
    

---

## **3. Endpoints & Usage**

### **3.1 Current Weather Data**

### **Request**

```
plaintext
CopyEdit
GET /weather?q={city_name}&appid={API_KEY}

```

### **Response (XML)**

```xml
xml
CopyEdit
<current>
   <city name="London"/>
   <temperature value="15" unit="Celsius"/>
   <humidity value="82%"/>
   <weather condition="Cloudy"/>
</current>

```

### **Example Use Case**

A travel website can use this API to display real-time weather for different destinations.

---

### **3.2 5-Day Weather Forecast**

### **Request**

```
plaintext
CopyEdit
GET /forecast?q={city_name}&days=5&appid={API_KEY}

```

### **Response (XML)**

```xml
xml
CopyEdit
<forecast>
   <day date="2025-02-08">
      <temperature value="18" unit="Celsius"/>
      <weather condition="Sunny"/>
   </day>
   <day date="2025-02-09">
      <temperature value="14" unit="Celsius"/>
      <weather condition="Rainy"/>
   </day>
</forecast>

```

### **Example Use Case**

A logistics company can integrate the forecast API to optimize delivery routes based on upcoming weather conditions.

---

## **4. Error Handling**

| HTTP Status Code | Meaning | Example Cause |
| --- | --- | --- |
| 400 | Bad Request | Missing or incorrect parameters |
| 401 | Unauthorized | Invalid or missing API key |
| 404 | Not Found | City not found |
| 500 | Server Error | Internal API issue |

### **Example Error Response (XML)**

```xml
xml
CopyEdit
<error>
   <code>401</code>
   <message>Invalid API Key</message>
</error>

```

---

## **5. Rate Limiting & Best Practices**

- **Rate Limit:** 60 requests per minute.
- **Optimize Requests:** Cache responses to reduce unnecessary API calls.
- **Use Efficient Queries:** Avoid fetching excessive historical data in a single request.

---

## **6. Implementing the API in Python**

### **Fetching Current Weather Data**

```python
python
CopyEdit
import requests

API_KEY = "YOUR_API_KEY"
CITY = "London"
URL = f"https://api.weatherdata.com/v1/weather?q={CITY}&appid={API_KEY}"

response = requests.get(URL)
print(response.text)

```

---

## **7. Conclusion**

This API allows developers to integrate weather data into their applications efficiently. The use of **HTML for documentation formatting** and **XML for structured data representation** ensures clarity and usability. Following best practices, developers can **optimize performance** and **enhance user experience** with real-time weather insights.

---

## **8. References**

- **OpenWeather API Documentation:** https://openweathermap.org/api
- **REST API Best Practices:** [https://restfulapi.net](https://restfulapi.net/)
- **XML in API Responses:** [https://www.w3.org/XML](https://www.w3.org/XML)