# API Documentation: RESTful API for AI-Powered Chatbot

## **Introduction**

This document provides a comprehensive guide to the RESTful API for an **AI-powered chatbot**, detailing the **endpoints, request/response formats, authentication**, and usage examples.

---

## **1. API Overview**

The AI-powered chatbot API allows developers to **send messages**, retrieve responses, and manage user sessions.

### **Base URL**

```
arduino
CopyEdit
https://api.chatbotai.com/v1/

```

### **Authentication**

All requests require an API key sent in the `Authorization` header.

Example:

```
makefile
CopyEdit
Authorization: Bearer YOUR_API_KEY

```

---

## **2. API Endpoints**

### **1. Send Message**

**Endpoint:**

```
bash
CopyEdit
POST /chat/send

```

**Request Headers:**

```json
json
CopyEdit
{
  "Content-Type": "application/json",
  "Authorization": "Bearer YOUR_API_KEY"
}

```

**Request Body (JSON):**

```json
json
CopyEdit
{
  "user_id": "12345",
  "message": "Hello, how are you?"
}

```

**Response (JSON):**

```json
json
CopyEdit
{
  "response": "I am fine. How can I assist you?",
  "timestamp": "2025-02-07T12:34:56Z"
}

```

---

### **2. Retrieve Chat History**

**Endpoint:**

```
bash
CopyEdit
GET /chat/history/{user_id}

```

**Response:**

```json
json
CopyEdit
{
  "history": [
    {
      "message": "Hello!",
      "response": "Hi, how can I help?",
      "timestamp": "2025-02-07T12:00:00Z"
    }
  ]
}

```

---

### **3. Manage User Sessions**

**Endpoint:**

```
pgsql
CopyEdit
DELETE /chat/session/{user_id}

```

**Response:**

```json
json
CopyEdit
{
  "status": "success",
  "message": "User session cleared"
}

```

---

## **3. XML Representation of Responses**

For clients needing **XML-formatted responses**, the API provides an XML response option.

Example Request Header:

```
bash
CopyEdit
Accept: application/xml

```

Example XML Response:

```xml
xml
CopyEdit
<response>
  <message>I am fine. How can I assist you?</message>
  <timestamp>2025-02-07T12:34:56Z</timestamp>
</response>

```

---

## **4. Error Handling**

| Error Code | Description |
| --- | --- |
| 400 | Bad Request – Invalid input format |
| 401 | Unauthorized – Invalid API key |
| 404 | Not Found – Endpoint does not exist |
| 500 | Internal Server Error – Try again later |

---

## **5. Rate Limits**

To prevent abuse, the API enforces rate limits:

- Free Tier: **1000 requests/day**
- Premium Tier: **Unlimited requests**

---

## **6. Example Usage in Python**

```python
python
CopyEdit
import requests

url = "https://api.chatbotai.com/v1/chat/send"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
}
data = {
    "user_id": "12345",
    "message": "Hello, chatbot!"
}
response = requests.post(url, json=data, headers=headers)
print(response.json())

```

---

## **7. Conclusion**

This API enables developers to integrate **AI chatbot capabilities** into applications efficiently, supporting both **JSON and XML** formats.