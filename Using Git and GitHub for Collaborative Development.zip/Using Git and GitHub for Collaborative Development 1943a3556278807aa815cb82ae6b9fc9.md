# Using Git and GitHub for Collaborative Development

## Introduction

Git and GitHub are essential tools for version control and collaborative development. This guide covers the basics of using Git and GitHub, including setup, workflows, and best practices for teams.

## 1. Setting Up Git and GitHub

### Install Git

Download and install Git from [git-scm.com](https://git-scm.com/).

```
# Check if Git is installed
$ git --version

```

### Configure Git

```
$ git config --global user.name "Your Name"
$ git config --global user.email "your.email@example.com"

```

### Create a GitHub Account

Sign up at [GitHub](https://github.com/) and set up SSH authentication for secure access.

## 2. Initializing a Repository

To start tracking a project with Git:

```
$ git init

```

Clone an existing repository from GitHub:

```
$ git clone https://github.com/username/repository.git

```

## 3. Basic Git Workflow

### Staging and Committing Changes

```
$ git add filename.py  # Stage a specific file
$ git add .  # Stage all changes
$ git commit -m "Descriptive commit message"

```

### Viewing History

```
$ git log --oneline --graph --all

```

## 4. Working with Remote Repositories

### Adding and Fetching from a Remote

```
$ git remote add origin https://github.com/username/repository.git
$ git fetch origin

```

### Pushing Changes

```
$ git push origin main  # Push changes to the main branch

```

### Pulling Changes

```
$ git pull origin main  # Sync with remote repository

```

## 5. Branching and Merging

### Creating and Switching Branches

```
$ git branch feature-branch
$ git checkout feature-branch

```

### Merging Branches

```
$ git checkout main
$ git merge feature-branch

```

## 6. Resolving Merge Conflicts

When conflicts arise, edit the affected files, then:

```
$ git add conflicted_file.py
$ git commit -m "Resolved merge conflict"

```

## 7. Best Practices

- Write meaningful commit messages.
- Use `.gitignore` to exclude unnecessary files.
- Regularly sync with the remote repository.
- Review code through pull requests before merging.

## Conclusion

Git and GitHub enable efficient collaboration in software development. Mastering these tools improves code quality, traceability, and teamwork.

## References

- Git Documentation: [https://git-scm.com/doc](https://git-scm.com/doc)
- GitHub Guides: [https://docs.github.com/en/github](https://docs.github.com/en/github)